const JSON_HEADERS = {
  "content-type": "application/json; charset=UTF-8",
  "cache-control": "no-store"
};

function json(data, status = 200, extra = {}) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { ...JSON_HEADERS, ...extra }
  });
}

function corsHeaders(origin) {
  return {
    "access-control-allow-origin": origin || "*",
    "access-control-allow-methods": "GET,OPTIONS",
    "access-control-allow-headers": "content-type"
  };
}

function isPrivateHost(hostname) {
  const h = hostname.toLowerCase().replace(/^\[|\]$/g, "");
  if (h === "localhost" || h.endsWith(".localhost") || h === "::1") return true;
  if (/^(10|127)\./.test(h) || /^192\.168\./.test(h) || /^169\.254\./.test(h)) return true;
  if (/^172\.(1[6-9]|2\d|3[0-1])\./.test(h)) return true;
  if (h === "0.0.0.0" || h === "::") return true;
  return false;
}

async function handleIp(request) {
  const cf = request.cf || {};
  const headers = request.headers;
  const ip = headers.get("CF-Connecting-IP") || "Unknown";
  let geo = null;
  try {
    const r = await fetch(`https://ipwho.is/${encodeURIComponent(ip)}`, { cf: { cacheTtl: 300, cacheEverything: true } });
    if (r.ok) geo = await r.json();
  } catch {}
  return json({
    ip,
    ipv4: ip.includes(":") ? null : ip,
    ipv6: ip.includes(":") ? ip : null,
    country: geo?.country || cf.country || null,
    country_code: geo?.country_code || cf.country || null,
    city: geo?.city || cf.city || null,
    region: geo?.region || cf.region || null,
    postal: geo?.postal || cf.postalCode || null,
    timezone: geo?.timezone?.id || cf.timezone || null,
    isp: geo?.connection?.isp || null,
    org: geo?.connection?.org || null,
    asn: geo?.connection?.asn ? `AS${geo.connection.asn}` : null,
    latitude: geo?.latitude ?? cf.latitude ?? null,
    longitude: geo?.longitude ?? cf.longitude ?? null,
    user_agent: headers.get("User-Agent") || ""
  });
}

async function dnsLookup(url) {
  const name = url.searchParams.get("name")?.trim();
  const type = (url.searchParams.get("type") || "A").toUpperCase();
  const allowed = new Set(["A", "AAAA", "MX", "CNAME", "NS", "TXT"]);
  if (!name || !allowed.has(type)) return json({ error: "Invalid domain or record type." }, 400);
  if (!/^[a-zA-Z0-9._-]+$/.test(name)) return json({ error: "Invalid domain." }, 400);
  const endpoint = `https://cloudflare-dns.com/dns-query?name=${encodeURIComponent(name)}&type=${type}`;
  const r = await fetch(endpoint, { headers: { accept: "application/dns-json" } });
  if (!r.ok) return json({ error: "DNS provider returned an error." }, 502);
  const data = await r.json();
  return json({ name, type, status: data.Status, answers: data.Answer || [] });
}

async function dnsLeak() {
  const resolvers = [
    ["Cloudflare", "https://cloudflare-dns.com/dns-query?name=whoami.cloudflare&type=TXT"],
    ["Google", "https://dns.google/resolve?name=whoami.cloudflare&type=TXT"],
    ["Quad9", "https://dns.quad9.net:5053/dns-query?name=whoami.cloudflare&type=TXT"]
  ];
  const results = await Promise.all(resolvers.map(async ([name, endpoint]) => {
    try {
      const r = await fetch(endpoint, { headers: { accept: "application/dns-json" } });
      const data = await r.json();
      return { resolver: name, ok: r.ok, answers: data.Answer || [] };
    } catch (e) {
      return { resolver: name, ok: false, answers: [], error: "Request failed" };
    }
  }));
  return json({ note: "This is a diagnostic resolver comparison, not a definitive device-wide DNS leak guarantee.", results });
}

async function headersCheck(url) {
  const target = url.searchParams.get("url")?.trim();
  if (!target) return json({ error: "Enter a URL." }, 400);
  let parsed;
  try { parsed = new URL(target); } catch { return json({ error: "Invalid URL." }, 400); }
  if (!/^https?:$/.test(parsed.protocol)) return json({ error: "Only HTTP and HTTPS URLs are allowed." }, 400);
  if (isPrivateHost(parsed.hostname)) return json({ error: "Private/local hosts are not allowed." }, 400);
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 8000);
  try {
    const r = await fetch(parsed.toString(), { method: "GET", redirect: "follow", signal: controller.signal, headers: { "User-Agent": "Nazuaf-Network-Tools/1.0" } });
    const out = {};
    for (const [k, v] of r.headers.entries()) out[k] = v;
    return json({ url: r.url, status: r.status, status_text: r.statusText, headers: out });
  } catch (e) {
    return json({ error: "Could not fetch that URL." }, 502);
  } finally { clearTimeout(timer); }
}

async function portCheck(url) {
  const host = url.searchParams.get("host")?.trim();
  const port = Number(url.searchParams.get("port"));
  if (!host || !Number.isInteger(port) || port < 1 || port > 65535) return json({ error: "Invalid host or port." }, 400);
  if (isPrivateHost(host)) return json({ error: "Private/local hosts are not allowed." }, 400);
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 5000);
  try {
    const r = await fetch(`http://${host}:${port}/`, { method: "HEAD", redirect: "manual", signal: controller.signal });
    return json({ host, port, reachable: true, status: r.status, note: "An HTTP service responded on this port." });
  } catch {
    return json({ host, port, reachable: false, note: "No HTTP response was received. This does not prove that a raw TCP port is closed." });
  } finally { clearTimeout(timer); }
}

export default {
  async fetch(request) {
    const origin = request.headers.get("Origin") || "*";
    if (request.method === "OPTIONS") return new Response(null, { headers: corsHeaders(origin) });
    const url = new URL(request.url);
    let response;
    try {
      if (url.pathname === "/api/ip") response = await handleIp(request);
      else if (url.pathname === "/api/dns") response = await dnsLookup(url);
      else if (url.pathname === "/api/dns-leak") response = await dnsLeak();
      else if (url.pathname === "/api/headers") response = await headersCheck(url);
      else if (url.pathname === "/api/port") response = await portCheck(url);
      else response = await env.ASSETS.fetch(request);
    } catch (e) {
      response = json({ error: "Unexpected server error." }, 500);
    }
    const h = new Headers(response.headers);
    for (const [k, v] of Object.entries(corsHeaders(origin))) h.set(k, v);
    return new Response(response.body, { status: response.status, headers: h });
  }
};
